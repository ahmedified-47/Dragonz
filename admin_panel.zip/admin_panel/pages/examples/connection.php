<?php
$conn = mysqli_connect("localhost" , "root" , "" , "shop_city") or die("Error Connecting");
?>
